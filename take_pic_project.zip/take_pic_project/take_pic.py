import csv
import matplotlib.pyplot as plt
area = []
price = []
with open('data.csv',newline='') as csvfile:
    row = csv.reader(csvfile)
    for rows in row:
        if(rows[1]!='average price'):
            area.append(rows[0])
            price.append(rows[1])
        else:
            area.append('')
            price.append('0')
plt.bar(area,price)
plt.show()
